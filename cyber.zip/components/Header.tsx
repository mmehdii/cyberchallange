'use client';

import { useState } from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';
import { List } from 'phosphor-react';
import Sidebar from './Sidebar';
import Search from './Search';

export default function Header() {
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const pathname = usePathname();

  return (
    <>
      <header className="bg-slate-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex items-center justify-between h-16">
            <div className="flex items-center">
              <button 
                onClick={() => setSidebarOpen(true)}
                className="md:hidden mr-2 flex items-center justify-center"
              >
                <List size={24} weight="regular" className="text-dark" />
              </button>
              <Link href="/" className="text-xl font-bold text-dark">
                CyberChallenge
              </Link>
            </div>
            
            <nav className="hidden md:flex items-center space-x-8">
              <Link href="/" className={`${pathname === '/' ? 'text-primary' : 'text-dark hover:text-blue-600'}`}>
                Home
              </Link>
              <Link href="/modules" className={`${pathname === '/modules' ? 'text-primary' : 'text-dark hover:text-blue-600'}`}>
                Learn
              </Link>
              <Link href="/resources" className={`${pathname === '/resources' ? 'text-primary' : 'text-dark hover:text-blue-600'}`}>
                Resources
              </Link>
              <Link href="/about" className={`${pathname === '/about' ? 'text-primary' : 'text-dark hover:text-blue-600'}`}>
                Contact
              </Link>
            </nav>
            
            <div className="flex items-center">
              <Search />
            </div>
          </div>
        </div>
      </header>
      
      <Sidebar isOpen={sidebarOpen} onClose={() => setSidebarOpen(false)} />
    </>
  );
}