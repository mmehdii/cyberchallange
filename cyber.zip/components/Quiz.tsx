'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import Button from './Button';

interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctAnswer: number;
}

interface QuizProps {
  questions: QuizQuestion[];
  onComplete: (score: number) => void;
}

export default function Quiz({ questions, onComplete }: QuizProps) {
  const [currentQuestion, setCurrentQuestion] = useState(0);
  const [selectedOption, setSelectedOption] = useState<number | null>(null);
  const [score, setScore] = useState(0);
  const [showFeedback, setShowFeedback] = useState(false);
  const [isCorrect, setIsCorrect] = useState(false);

  const handleOptionSelect = (index: number) => {
    setSelectedOption(index);
  };

  const handleNextQuestion = () => {
    // Check if answer is correct
    const correct = selectedOption === questions[currentQuestion].correctAnswer;
    
    if (correct) {
      setScore(score + 1);
      setIsCorrect(true);
    } else {
      setIsCorrect(false);
    }
    
    setShowFeedback(true);
    
    // Move to next question after delay
    setTimeout(() => {
      setShowFeedback(false);
      setSelectedOption(null);
      
      if (currentQuestion < questions.length - 1) {
        setCurrentQuestion(currentQuestion + 1);
      } else {
        onComplete(score + (correct ? 1 : 0));
      }
    }, 1500);
  };

  const currentQuizQuestion = questions[currentQuestion];

  return (
    <div className="p-4 md:p-6 max-w-2xl mx-auto">
      <div className="mb-6 md:mb-8 flex justify-between items-center">
        <p className="text-sm md:text-base text-muted">Question {currentQuestion + 1} of {questions.length}</p>
        <p className="text-sm md:text-base font-bold">Score: {score}</p>
      </div>
      
      <h2 className="text-xl md:text-2xl font-bold mb-6 md:mb-8">{currentQuizQuestion.question}</h2>
      
      <div className="space-y-4 md:space-y-6 mb-8 md:mb-10">
        {currentQuizQuestion.options.map((option, index) => (
          <motion.button
            key={index}
            onClick={() => handleOptionSelect(index)}
            className={`w-full p-4 md:p-5 rounded-lg border text-left transition-colors ${
              selectedOption === index 
                ? 'border-primary bg-primary bg-opacity-10' 
                : 'border-secondary hover:border-primary'
            }`}
            whileTap={{ scale: 0.98 }}
            disabled={showFeedback}
          >
            <span className="text-base md:text-lg">{option}</span>
          </motion.button>
        ))}
      </div>
      
      {showFeedback && (
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className={`p-4 md:p-5 rounded-lg mb-6 md:mb-8 ${
            isCorrect ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800'
          }`}
        >
          <p className="font-medium text-base md:text-lg">
            {isCorrect 
              ? '✓ Correct!' 
              : `✗ Incorrect. The correct answer is: ${
                  currentQuizQuestion.options[currentQuizQuestion.correctAnswer]
                }`
            }
          </p>
        </motion.div>
      )}
      
      <Button
        onClick={handleNextQuestion}
        disabled={selectedOption === null}
        className={`w-full md:max-w-md mx-auto ${selectedOption === null ? 'opacity-50 cursor-not-allowed' : ''}`}
      >
        {currentQuestion < questions.length - 1 ? 'Next Question' : 'Finish Quiz'}
      </Button>
    </div>
  );
}