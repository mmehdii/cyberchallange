'use client';
import { Resource } from '@/data/resources';
import { BookOpen, PlayCircle, FileText } from 'phosphor-react';

interface ResourceCardProps {
  resource: Resource;
}

export default function ResourceCard({ resource }: ResourceCardProps) {
  const getIcon = () => {
    switch (resource.type) {
      case 'video':
        return <PlayCircle size={24} weight="fill" className="text-primary" />;
      case 'article':
        return <FileText size={24} weight="fill" className="text-primary" />;
      case 'guide':
        return <BookOpen size={24} weight="fill" className="text-primary" />;
      default:
        return <BookOpen size={24} weight="fill" className="text-primary" />;
    }
  };

  return (
    <a 
      href={resource.link} 
      className="block p-4 md:p-6 border rounded-xl mb-4 hover:shadow-lg transition-shadow duration-300"
      target="_blank"
      rel="noopener noreferrer"
    >
      <div className="flex gap-4 md:gap-6">
        <div className="flex-shrink-0">
          {getIcon()}
        </div>
        <div className="flex-1">
          <h3 className="text-base md:text-lg font-bold mb-2 md:mb-3">{resource.title}</h3>
          <p className="text-sm md:text-base text-muted mb-3 md:mb-4">{resource.description}</p>
          <div className="flex justify-between items-center text-xs md:text-sm text-muted">
            <span>{resource.source}</span>
            <span>{resource.date}</span>
          </div>
        </div>
      </div>
    </a>
  );
}