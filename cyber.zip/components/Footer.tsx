'use client';

import Link from 'next/link';
import { House, ArrowCircleRight, Phone } from 'phosphor-react';
import { usePathname } from 'next/navigation';

export default function Footer() {
  const pathname = usePathname();
  
  
  return (
    <footer className="mt-24 bg-slate-100 text-dark py-4">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="md:hidden grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <p className="text-sm text-muted">
              © {new Date().getFullYear()} Cybersecurity Awareness Challenge
            </p>
          </div>
          
          <div className="text-right">
            <ul className="flex justify-end gap-4 text-sm text-muted">
              <li><a href="/" className="hover:text-primary transition-colors">Home</a></li>
              <li><a href="/modules" className="hover:text-primary transition-colors">Modules</a></li>
              <li><a href="/resources" className="hover:text-primary transition-colors">Resources</a></li>
            </ul>
          </div>
        </div>

        <div className="hidden md:block text-center">
          <p className="text-sm text-muted">
            © {new Date().getFullYear()} Cybersecurity Awareness Challenge
          </p>
        </div>
      </div>
    </footer>
  );
}