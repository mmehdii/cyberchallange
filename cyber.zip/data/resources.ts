export type Resource = {
    id: string;
    title: string;
    description: string;
    link: string;
    type: 'video' | 'article' | 'guide';
    source: string;
    date: string;
  };
  
  export const resourcesData: Resource[] = [
    // Videos
    {
      id: 'video-phishing',
      title: 'How to Spot a Phishing Email',
      description: 'Learn the key indicators of phishing emails and how to protect yourself',
      link: '#',
      type: 'video',
      source: 'CyberSafe Academy',
      date: 'March 15, 2024'
    },
    {
      id: 'video-passwords',
      title: 'Creating Strong Passwords That Are Easy to Remember',
      description: 'Techniques for creating and remembering complex, secure passwords',
      link: '#',
      type: 'video',
      source: 'Security Explained',
      date: 'February 8, 2024'
    },
    {
      id: 'video-malware',
      title: 'Malware Explained: Types and Prevention',
      description: 'Understanding different types of malware and how to prevent infections',
      link: '#',
      type: 'video',
      source: 'Tech Defenders',
      date: 'April 2, 2024'
    },
    
    // Articles
    {
      id: 'article-vpn',
      title: 'Why You Should Use a VPN',
      description: 'The importance of VPNs for online privacy and security',
      link: '#',
      type: 'article',
      source: 'Digital Privacy Blog',
      date: 'January 20, 2024'
    },
    {
      id: 'article-social',
      title: 'Social Media Privacy Settings You Should Enable Now',
      description: 'A comprehensive guide to securing your social media accounts',
      link: '#',
      type: 'article',
      source: 'Privacy Today',
      date: 'March 30, 2024'
    },
    {
      id: 'article-threats',
      title: 'Emerging Cybersecurity Threats in 2024',
      description: 'Stay informed about the latest cyber threats and how to protect yourself',
      link: '#',
      type: 'article',
      source: 'Cyber Defense Magazine',
      date: 'April 10, 2024'
    },
    
    // Guides
    {
      id: 'guide-parents',
      title: 'Parents\' Guide to Online Safety',
      description: 'How to keep your children safe online and teach them good cyber habits',
      link: '#',
      type: 'guide',
      source: 'Internet Safety Coalition',
      date: 'February 12, 2024'
    },
    {
      id: 'guide-mobile',
      title: 'Mobile Device Security Guide',
      description: 'Essential steps to secure your smartphone and tablet',
      link: '#',
      type: 'guide',
      source: 'Mobile Security Institute',
      date: 'January 5, 2024'
    },
    {
      id: 'guide-remote',
      title: 'Securing Your Home Network',
      description: 'A complete guide to securing your home Wi-Fi and connected devices',
      link: '#',
      type: 'guide',
      source: 'Home Network Security',
      date: 'March 22, 2024'
    }
  ];
  
  export type GlossaryTerm = {
    term: string;
    definition: string;
  };
  
  export const glossaryTerms: GlossaryTerm[] = [
    {
      term: 'Malware',
      definition: 'Short for "malicious software," refers to any software intentionally designed to cause damage to a computer, server, client, or computer network.'
    },
    {
      term: 'Phishing',
      definition: 'A cyberattack that uses disguised email as a weapon. The goal is to trick the email recipient into believing that the message is something they want or need.'
    },
    {
      term: 'Ransomware',
      definition: 'A type of malicious software designed to block access to a computer system until a sum of money is paid.'
    },
    {
      term: 'Two-Factor Authentication (2FA)',
      definition: 'A security process in which users provide two different authentication factors to verify themselves, providing an additional layer of security.'
    },
    {
      term: 'VPN (Virtual Private Network)',
      definition: 'Extends a private network across a public network, enabling users to send and receive data across shared or public networks as if their devices were directly connected to the private network.'
    },
    {
      term: 'Firewall',
      definition: 'A network security system that monitors and controls incoming and outgoing network traffic based on predetermined security rules.'
    },
    {
      term: 'Encryption',
      definition: 'The process of converting information or data into a code to prevent unauthorized access.'
    },
    {
      term: 'Social Engineering',
      definition: 'The psychological manipulation of people into performing actions or divulging confidential information.'
    },
    {
      term: 'Antivirus',
      definition: 'Software designed to detect, prevent, and remove malicious software.'
    },
    {
      term: 'Botnet',
      definition: 'A network of private computers infected with malicious software and controlled without the owners\' knowledge.'
    },
    {
      term: 'DDoS (Distributed Denial of Service)',
      definition: 'An attack where multiple compromised systems are used to target a single system causing a denial of service.'
    },
    {
      term: 'Keylogger',
      definition: 'A software program or hardware device that records the real-time activity of a computer user including the keyboard keys they press.'
    }
  ];